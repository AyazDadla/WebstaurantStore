/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9266666666666666, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "RQ Item 829BMR49R"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "RQ Item 178SSUC48FHC"], "isController": false}, {"data": [1.0, 500, 1500, "RQ Item 236ECEM2"], "isController": false}, {"data": [0.8333333333333334, 500, 1500, "RQ Item 178APT60HC"], "isController": false}, {"data": [0.8571428571428571, 500, 1500, "RQ Item 177GDN5RBB"], "isController": false}, {"data": [1.0, 500, 1500, "RQ Item 178CBE36HC"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "RQ Item 348SM60"], "isController": false}, {"data": [0.8571428571428571, 500, 1500, "RQ Item178A23FHC"], "isController": false}, {"data": [1.0, 500, 1500, "RQ Item 178UBB72GHCS"], "isController": false}, {"data": [0.875, 500, 1500, "RQ Item 178A23RGHC"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 75, 0, 0.0, 417.7466666666668, 269, 1309, 375.0, 569.0000000000002, 726.0000000000006, 1309.0, 0.08443236123541431, 29.33995309430532, 0.012939699111208678], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["RQ Item 829BMR49R", 6, 0, 0.0, 330.5, 276, 404, 324.0, 404.0, 404.0, 404.0, 0.007689192583517447, 2.0870100622696444, 0.001171400432645236], "isController": false}, {"data": ["RQ Item 178SSUC48FHC", 6, 0, 0.0, 404.8333333333333, 309, 599, 353.5, 599.0, 599.0, 599.0, 0.008326256015719971, 2.536304427694793, 0.0012928463930658941], "isController": false}, {"data": ["RQ Item 236ECEM2", 6, 0, 0.0, 354.6666666666667, 320, 414, 349.5, 414.0, 414.0, 414.0, 0.008767686981884498, 2.651003772297324, 0.0013271401193282197], "isController": false}, {"data": ["RQ Item 178APT60HC", 6, 0, 0.0, 456.1666666666667, 320, 688, 416.5, 688.0, 688.0, 688.0, 0.007240404352448403, 3.03684642717722, 0.0011101010579437492], "isController": false}, {"data": ["RQ Item 177GDN5RBB", 7, 0, 0.0, 544.5714285714286, 278, 1309, 381.0, 1309.0, 1309.0, 1309.0, 0.008213263246820294, 2.0698695246133902, 0.0012592600876472522], "isController": false}, {"data": ["RQ Item 178CBE36HC", 6, 0, 0.0, 339.5, 271, 462, 312.5, 462.0, 462.0, 462.0, 0.00861702494341487, 2.487668061158616, 0.0013211649571446625], "isController": false}, {"data": ["RQ Item 348SM60", 6, 0, 0.0, 468.3333333333333, 269, 1193, 338.5, 1193.0, 1193.0, 1193.0, 0.007140757420139554, 2.152029496237416, 0.0010739029713881753], "isController": false}, {"data": ["RQ Item178A23FHC", 7, 0, 0.0, 445.85714285714283, 337, 636, 398.0, 636.0, 636.0, 636.0, 0.0089698165672512, 3.2422745953171153, 0.001366495492667175], "isController": false}, {"data": ["RQ Item 178UBB72GHCS", 13, 0, 0.0, 381.38461538461536, 328, 451, 384.0, 439.8, 451.0, 451.0, 0.01616121432878126, 6.449218045860554, 0.0025094073030041213], "isController": false}, {"data": ["RQ Item 178A23RGHC", 12, 0, 0.0, 443.00000000000006, 348, 606, 421.5, 588.9000000000001, 606.0, 606.0, 0.016657574407302683, 7.291579366227878, 0.0025539445136196492], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 75, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
